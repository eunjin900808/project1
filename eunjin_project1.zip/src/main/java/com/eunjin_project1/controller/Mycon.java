package com.eunjin_project1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Mycon {

	@GetMapping("test1")
	public String test1() {
		return "cart/test1";
	}
}
