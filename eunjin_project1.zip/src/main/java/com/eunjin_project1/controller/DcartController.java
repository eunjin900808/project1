package com.eunjin_project1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DcartController {

	@GetMapping("dCart")
	public String dcart() {
		return "cart/dCart";
	}
	
	@GetMapping("dCartList")
	public String dcartList() {
		return "cart/dCartList";
	}
	
	@GetMapping("dCartResult")
	public String dCartResult() {
		return "cart/dCartResult";
	}
	
}