package com.eunjin_project1.mapper;

public interface DcartMapper {

}
