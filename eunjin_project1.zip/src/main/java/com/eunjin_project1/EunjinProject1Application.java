package com.eunjin_project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EunjinProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(EunjinProject1Application.class, args);
	}

}
